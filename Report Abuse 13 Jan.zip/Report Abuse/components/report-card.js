// Report Card Web Component
class ReportCard extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    const report = {
      id: this.getAttribute('data-id'),
      abuse_type: this.getAttribute('data-abuse-type'),
      status: this.getAttribute('data-status') || 'New',
      perpetrator_name: this.getAttribute('data-perpetrator') || 'Anonymous',
      relationship: this.getAttribute('data-relationship'),
      location: this.getAttribute('data-location'),
      date: this.getAttribute('data-date')
    };

    // Determine status badge color
    let statusColor = 'bg-blue-100 text-blue-800';
    let statusLabel = 'New';
    
    if (report.status === 'in-progress') {
      statusColor = 'bg-yellow-100 text-yellow-800';
      statusLabel = 'In-Progress';
    } else if (report.status === 'resolved') {
      statusColor = 'bg-green-100 text-green-800';
      statusLabel = 'Resolved';
    }

    this.innerHTML = `
      <div class="report-card bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden transition-transform duration-300 hover:scale-105">
        <div class="p-6">
          <!-- Status Badge -->
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-lg font-semibold text-gray-800">${this.escapeHtml(report.abuse_type)}</h3>
            <span class="px-3 py-1 rounded-full text-xs font-medium ${statusColor}">
              ${statusLabel}
            </span>
          </div>
          <hr>

          <!-- Report Summary -->
          <div class="space-y-3 text-sm text-gray-600 mt-4">
            <div class="flex items-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2 text-gray-400">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
              <span>${this.escapeHtml(report.perpetrator_name)}</span>
            </div>
            <div class="flex items-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2 text-gray-400">
                <rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect>
                <path d="M16 3l-4 4-4-4"></path>
              </svg>
              <span>${this.escapeHtml(report.relationship)}</span>
            </div>
            <div class="flex items-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2 text-gray-400">
                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                <circle cx="12" cy="10" r="3"></circle>
              </svg>
              <span>${this.escapeHtml(report.location)}</span>
            </div>
            <div class="flex items-center">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2 text-gray-400">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
              </svg>
              <span>${this.escapeHtml(report.date)}</span>
            </div>
          </div>

          <!-- View Details Button -->
          <button onclick="viewReportDetails(${report.id})" class="mt-6 w-25 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition">
            View Details
          </button>
        </div>
      </div>
    `;
  }

  escapeHtml(text) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
  }
}

customElements.define('report-card', ReportCard);
