class AuthCard extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    max-width: 28rem;
                    width: 100%;
                    margin: 0 auto;
                }
                
                .card {
                    background: white;
                    border-radius: 1rem;
                    overflow: hidden;
                    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
                }
                
                .header {
                    background: linear-gradient(to right, #6366f1, #4f46e5);
                    padding: 1.5rem;
                    text-align: center;
                }
                
                .content {
                    padding: 1.5rem;
                }
                
                .footer {
                    background: #f9fafb;
                    padding: 1rem 1.5rem;
                    text-align: center;
                    border-top: 1px solid #e5e7eb;
                }
            </style>
            
            <div class="card">
                <div class="header">
                    <slot name="header"></slot>
                </div>
                <div class="content">
                    <slot name="content"></slot>
                </div>
                <div class="footer">
                    <slot name="footer"></slot>
                </div>
            </div>
        `;
    }
}

customElements.define('auth-card', AuthCard);