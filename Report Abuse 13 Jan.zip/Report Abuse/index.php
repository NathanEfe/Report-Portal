<?php
session_start();
include_once 'cbase.php';
$config = new Config();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delsu Report Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <link rel="shortcut icon" href="img/delsu.png">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            500: '#3b82f6',
                            600: '#2563eb',
                        },
                        secondary: {
                            500: '#64748b',
                            600: '#475569',
                        }
                    }
                }
            }
        }
    </script>
    <style>
      .delsu-logo {
        width: 50px;
        height: 40px;
        margin-right: 10px;
      }
      .hidden-field {
        display: none;
      }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <!-- Header -->
            <div class="bg-primary-500 px-6 py-4">
                <div class="flex items-center">
                    <img src="img/delsu.png" class="delsu-logo"  alt="">
                    <h1 class="text-2xl font-bold text-white">Delta State University, Abraka</h1>
                </div>
                <p class="text-primary-100 mt-1">Your report will be handled with confidentiality and care</p>
            </div>

            <!-- Form Container -->
            <div class="p-6 md:p-8">
                <form action="submit_report.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <!-- Name Field -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Name (Optional)</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i data-feather="user" class="text-gray-400"></i>
                            </div>
                            <input type="text" name="name" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" placeholder="Leave blank to stay anonymous">
                        </div>
                    </div>

                    <!-- Abuse Type -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Nature of Abuse <span class="text-red-500">*</span></label>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div class="flex items-center">
                                <input id="physical" name="abuse_type" type="radio" value="Physical Abuse" required class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300">
                                <label for="physical" class="ml-2 block text-sm text-gray-700">Physical Abuse</label>
                            </div>
                            <div class="flex items-center">
                                <input id="verbal" name="abuse_type" type="radio" value="Verbal/Emotional Abuse" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300">
                                <label for="verbal" class="ml-2 block text-sm text-gray-700">Verbal/Emotional Abuse</label>
                            </div>
                            <div class="flex items-center">
                                <input id="sexual" name="abuse_type" type="radio" value="Sexual Assault" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300">
                                <label for="sexual" class="ml-2 block text-sm text-gray-700">Sexual Assault</label>
                            </div>
                            <div class="flex items-center">
                                <input id="stalking" name="abuse_type" type="radio" value="Stalking" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300">
                                <label for="stalking" class="ml-2 block text-sm text-gray-700">Stalking</label>
                            </div>
                            <div class="flex items-center">
                                <input id="other-abuse" name="abuse_type" type="radio" value="Other" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" onchange="toggleOtherAbuseType()">
                                <label for="other-abuse" class="ml-2 block text-sm text-gray-700">Other</label>
                            </div>
                        </div>
                    </div>
                    <!-- Hidden textbox for Other Abuse Type -->
                    <div id="other-abuse-type-field" class="hidden-field space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Please specify other abuse type</label>
                        <input type="text" name="other_abuse_type" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" placeholder="Specify the type of abuse">
                    </div>

                    <!-- Relationship -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Position of Perpetrator <span class="text-red-500">*</span></label>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div class="flex items-center">
                                <input id="spouse" name="relationship" type="radio" value="Academic Staff" required class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" onchange="togglePositionFields()">
                                <label for="spouse" class="ml-2 block text-sm text-gray-700">Academic Staff</label>
                            </div>
                            <div class="flex items-center">
                                <input id="family" name="relationship" type="radio" value="Non Teaching Staff" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" onchange="togglePositionFields()">
                                <label for="family" class="ml-2 block text-sm text-gray-700">Non Teaching Staff</label>
                            </div>
                            <div class="flex items-center">
                                <input id="stranger" name="relationship" type="radio" value="Student" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" onchange="togglePositionFields()">
                                <label for="stranger" class="ml-2 block text-sm text-gray-700">Student</label>
                            </div>
                            <div class="flex items-center">
                                <input id="other-relation" name="relationship" type="radio" value="Other" class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" onchange="toggleOtherPosition(); togglePositionFields();">
                                <label for="other-relation" class="ml-2 block text-sm text-gray-700">Other</label>
                            </div>
                        </div>
                    </div>
                    <!-- Hidden textbox for Other Position -->
                    <div id="other-position-field" class="hidden-field space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Please specify other position</label>
                        <input type="text" name="other_position" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" placeholder="Specify the position of perpetrator">
                    </div>

                      <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="faculty-department-div" style="display: none;">
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Faculty of Perpetrator </label>
                            <select name="faculty" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" id="faculty-select">
                                <option value="" disabled selected>Select an option</option>
                                <?php $config->FetchAllFacultiesDropdown(); ?>
                            </select>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Department of Perpetrator</label>
                            <select name="department" id="department-select" 
                                    class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500">
                                    <!-- Fetch department based on faculty AJAX -->
                              <option value="" disabled selected>Select a department</option>
                            </select>
                          </div>

                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6" id="unit-div" style="display: none;">
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Unit  of Perpetrator </label>
                            <select name="unit" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500">
                                <option value="" disabled selected>Select an option</option>
                                <?php $config->FetchAllUnitsDropdown(); ?>
                            </select>
                        </div>
                        
                    </div>
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Name of Perpetrator (Optional)</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i data-feather="user" class="text-gray-400"></i>
                            </div>
                            <input type="text" name="Perpetratorname" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" placeholder="Leave blank to stay anonymous">
                        </div>
                    </div>

                    <!-- Incident Details -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Date/Time of Incident <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="calendar" class="text-gray-400"></i>
                                </div>
                                <input type="datetime-local" name="incident_datetime" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required>
                            </div>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Location of Incident <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i data-feather="map-pin" class="text-gray-400"></i>
                                </div>
                                <input type="text" name="location" class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required>
                            </div>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Description of What Happened <span class="text-red-500">*</span></label>
                        <textarea name="description" rows="4" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required></textarea>
                    </div>

                    <!-- Medical Info -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Specify If any physical injuries sustained <span class="text-red-500">*</span></label>
                            <input type="text" name="physical_injuries" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required>
                        </div>
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Did the victim seek medical attention? <span class="text-red-500">*</span></label>
                            <select name="medical_attention" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required>
                                <option value="" disabled selected>Select an option</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                    </div>

                    <!-- Authorities -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Did the victim report to authorities? <span class="text-red-500">*</span></label>
                        <select name="reported_to_authorities" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" required>
                            <option value="" disabled selected>Select an option</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                            <option value="Planning to">Planning to</option>
                        </select>
                    </div>

                    <!-- Witnesses -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Were there any witnesses?</label>
                            <select name="witnesses_present" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" onchange="toggleOtherWitness()">
                                <option value="" selected>Select an option</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                                <option value="Unsure">Unsure</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <!-- Hidden textbox for Other Witness Response -->
                        <div id="other-witness-field" class="hidden-field space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Please specify</label>
                            <input type="text" name="other_witness" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500" placeholder="Provide more details about witnesses">
                        </div>
                        <div class="space-y-2">
                            <label class="block text-sm font-medium text-gray-700">Contact information of witnesses (if available)</label>
                            <input type="text" name="witness_contact" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500">
                        </div>
                    </div>

                    <!-- Additional Info -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Any other information the victim wishes to share</label>
                        <textarea name="additional_info" rows="3" class="block w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-primary-500 focus:border-primary-500"></textarea>
                    </div>

                    <!-- Evidence Upload -->
                    <div class="space-y-2">
                        <label class="block text-sm font-medium text-gray-700">Upload Evidence (optional)</label>
                        <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                            <div class="space-y-1 text-center">
                                <div class="flex text-sm text-center text-gray-600">
                                    <label for="evidence" class="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none">
                                        <span>Upload a file</span>
                                        <input id="evidence" name="evidence" type="file" class="sr-only">
                                    </label>
                                    <p class="pl-1">or drag and drop</p>
                                </div>
                                <p class="text-xs text-gray-500 text-center">PNG, JPG, PDF, MP3, MP4 up to 100MB</p>
                                <progress id="file-progress" value="0" max="100" class="ml-2"></progress>
                              <p id="upload-status" class="text-sm text-gray-500 mt-2"></p>
                            </div>
                          </div>

                    </div>



                    <!-- Google reCAPTCHA v2 -->
                    <div class="space-y-2">
                        <?php if (!empty($_SESSION['captcha_error'])): ?>
                            <div class="text-red-600 text-sm"><?= htmlspecialchars($_SESSION['captcha_error']) ?></div>
                            <?php unset($_SESSION['captcha_error']); ?>
                        <?php endif; ?>
                        <label class="block text-sm font-medium text-gray-700">Please verify you're human <span class="text-red-500">*</span></label>
                        <div class="mt-2">
                            <div class="g-recaptcha" data-sitekey="6LdAMUUsAAAAAB2nmIGQSqDT64Ze043V8agbSpmW"></div>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="pt-4">
                        <button type="submit" class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary-500 hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors duration-200">
                            <i data-feather="send" class="mr-2"></i> Submit Report
                        </button>
                    </div>
                </form>
            </div>

            <!-- Footer -->
            <div class="bg-gray-50 px-6 py-4 border-t border-gray-200">
                <div class="flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
                    <div class="flex items-center mb-2 md:mb-0">
                        <i data-feather="lock" class="mr-2"></i>
                        <span>Your information is secure and confidential</span>
                    </div>
                    <div>
                        <a href="#" class="text-primary-600 hover:text-primary-500">Need help? Contact support</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $('#faculty-select').on('change', function() {
    var facultyId = $(this).val();

    if(facultyId) {
      $.ajax({
        url: 'fetch_departments.php',   // backend script
        type: 'POST',
        data: { faculty_id: facultyId },
        success: function(response) {
          $('#department-select').html(response);
        }
      });
    }
  });



const largeFileInput = document.getElementById('evidence');
const fileProgress = document.getElementById('file-progress');
const uploadStatus = document.getElementById('upload-status');

largeFileInput.addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        const percentComplete = (e.loaded / e.total) * 100;
        fileProgress.value = percentComplete;
        uploadStatus.textContent = `Uploading: ${percentComplete.toFixed(2)}%`;
      }
    };
    reader.onloadend = () => {
      uploadStatus.textContent = 'File upload complete';
    };
    reader.readAsDataURL(file);
  }
});   
</script>

    <script>
        feather.replace();

        // Toggle Faculty/Department and Unit divs based on position
        function togglePositionFields() {
            const selectedPosition = document.querySelector('input[name="relationship"]:checked').value;
            const facultyDeptDiv = document.getElementById('faculty-department-div');
            const unitDiv = document.getElementById('unit-div');

            if (selectedPosition === 'Academic Staff' || selectedPosition === 'Student') {
                facultyDeptDiv.style.display = 'grid';
                unitDiv.style.display = 'none';
            } else if (selectedPosition === 'Non Teaching Staff') {
                facultyDeptDiv.style.display = 'none';
                unitDiv.style.display = 'grid';
            } else {
                facultyDeptDiv.style.display = 'none';
                unitDiv.style.display = 'none';
            }
        }

        // Toggle "Other" abuse type field
        function toggleOtherAbuseType() {
            const field = document.getElementById('other-abuse-type-field');
            const isOtherSelected = document.getElementById('other-abuse').checked;
            field.style.display = isOtherSelected ? 'block' : 'none';
        }

        // Toggle "Other" position field
        function toggleOtherPosition() {
            const field = document.getElementById('other-position-field');
            const isOtherSelected = document.getElementById('other-relation').checked;
            field.style.display = isOtherSelected ? 'block' : 'none';
        }

        // Toggle "Other" witness field
        function toggleOtherWitness() {
            const field = document.getElementById('other-witness-field');
            const selectValue = document.querySelector('select[name="witnesses_present"]').value;
            field.style.display = selectValue === 'Other' ? 'block' : 'none';
        }
        
    </script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</body>
</html>