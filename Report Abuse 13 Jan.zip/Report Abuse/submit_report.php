<?php
session_start();
// Google reCAPTCHA v2 server-side verification
// Replace 'YOUR_SECRET_KEY' with your actual reCAPTCHA secret key
$recaptcha_secret = '6LdAMUUsAAAAAJlndGL4Pja04QOL_8xsI3evLEOw';
$recaptcha_response = $_POST['g-recaptcha-response'] ?? '';
if (empty($recaptcha_response)) {
    $_SESSION['captcha_error'] = 'reCAPTCHA verification failed. Please complete the checkbox and try again.';
    header('Location: index.php');
    exit();
}

// Verify with Google (cURL)        
$verify_url = 'https://www.google.com/recaptcha/api/siteverify';
$post_fields = http_build_query([
    'secret' => $recaptcha_secret,
    'response' => $recaptcha_response,
    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? ''
]);

$ch = curl_init($verify_url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$verify_response = curl_exec($ch);
curl_close($ch);

$decoded = json_decode($verify_response, true);
if (empty($decoded) || !isset($decoded['success']) || $decoded['success'] !== true) {
    $_SESSION['captcha_error'] = 'reCAPTCHA verification failed. Please try again.';
    header('Location: index.php');
    exit();
}

// Database credentials
include 'config.php';

// Sanitize inputs
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

$name = sanitize($_POST['name'] ?? '');
$abuse_type = $_POST['abuse_type'] ?? '';
$other_abuse_type = sanitize($_POST['other_abuse_type'] ?? '');
$relationship = $_POST['relationship'] ?? '';
$other_position = sanitize($_POST['other_position'] ?? '');
$faculty = sanitize($_POST['faculty'] ?? '');
$department = sanitize($_POST['department'] ?? '');
$unit = sanitize($_POST['unit'] ?? '');
$perpetrator_name = sanitize($_POST['Perpetratorname'] ?? '');
$incident_datetime = $_POST['incident_datetime'] ?? null;
$location = sanitize($_POST['location'] ?? '');
$description = sanitize($_POST['description'] ?? '');
$physical_injuries = sanitize($_POST['physical_injuries'] ?? '');
$medical_attention = sanitize($_POST['medical_attention'] ?? '');
$reported_to_authorities = sanitize($_POST['reported_to_authorities'] ?? '');
$witnesses_present = sanitize($_POST['witnesses_present'] ?? '');
$other_witness = sanitize($_POST['other_witness'] ?? '');
$witness_contact = sanitize($_POST['witness_contact'] ?? '');
$additional_info = sanitize($_POST['additional_info'] ?? '');

$support_needed = isset($_POST['support_needed']) ? implode(',', $_POST['support_needed']) : '';



// File upload handling
$evidence_file = null;

if (isset($_FILES['evidence']) && $_FILES['evidence']['error'] == 0) {
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'pdf', 'mp3'];
    $upload_dir = "uploads/";
    $original_name = basename($_FILES['evidence']['name']);
    $extension = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

    if (in_array($extension, $allowed_extensions)) {
        $unique_name = uniqid() . '_' . $original_name;
        $destination = $upload_dir . $unique_name;

        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        if (move_uploaded_file($_FILES['evidence']['tmp_name'], $destination)) {
            $evidence_file = $destination;
        }
    }
}



// Append "Other" specifications to main fields if provided
if ($abuse_type === 'Other' && !empty($other_abuse_type)) {
    $abuse_type = 'Other: ' . $other_abuse_type;
}
if ($relationship === 'Other' && !empty($other_position)) {
    $relationship = 'Other: ' . $other_position;
}
if ($witnesses_present === 'Other' && !empty($other_witness)) {
    $witnesses_present = 'Other: ' . $other_witness;
}

// If faculty/department/unit were submitted as IDs, resolve them to human-readable names
// This keeps the database storing names while the form can continue to post IDs.
if (!empty($faculty) && is_numeric($faculty)) {
    if ($stmtF = $conn->prepare("SELECT name FROM faculties WHERE id = ? LIMIT 1")) {
        $fid = (int)$faculty;
        $stmtF->bind_param('i', $fid);
        $stmtF->execute();
        $resF = $stmtF->get_result();
        if ($resF && $rowF = $resF->fetch_assoc()) {
            $faculty = sanitize($rowF['name']);
        }
        $stmtF->close();
    }
}
if (!empty($department) && is_numeric($department)) {
    if ($stmtD = $conn->prepare("SELECT name FROM departments WHERE id = ? LIMIT 1")) {
        $did = (int)$department;
        $stmtD->bind_param('i', $did);
        $stmtD->execute();
        $resD = $stmtD->get_result();
        if ($resD && $rowD = $resD->fetch_assoc()) {
            $department = sanitize($rowD['name']);
        }
        $stmtD->close();
    }
}
if (!empty($unit) && is_numeric($unit)) {
    if ($stmtU = $conn->prepare("SELECT name FROM units WHERE id = ? LIMIT 1")) {
        $uid = (int)$unit;
        $stmtU->bind_param('i', $uid);
        $stmtU->execute();
        $resU = $stmtU->get_result();
        if ($resU && $rowU = $resU->fetch_assoc()) {
            $unit = sanitize($rowU['name']);
        }
        $stmtU->close();
    }
}

$stmt = $conn->prepare("INSERT INTO abuse_reports 
    (name, abuse_type, relationship_to_perpetrator, faculty, department, unit, perpetrator_name, 
     incident_datetime, location_of_incident, description, 
     physical_injuries, medical_attention, reported_to_authorities, support_needed, 
     witnesses_present, witness_contact, additional_info, evidence_file)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");


$stmt->bind_param("ssssssssssssssssss", 
    $name, $abuse_type, $relationship, $faculty, $department, $unit, $perpetrator_name,
    $incident_datetime, $location, $description, 
    $physical_injuries, $medical_attention, $reported_to_authorities, $support_needed, 
    $witnesses_present, $witness_contact, $additional_info, $evidence_file
);


if ($stmt->execute()) {
    header("Location: thank_you.php");
    exit();
} else {
    echo "<h3>Error submitting report. Please try again later.</h3>";
}


$stmt->close();
$conn->close();
?>
