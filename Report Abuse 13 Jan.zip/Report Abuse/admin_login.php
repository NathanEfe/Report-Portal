<?php
session_start();
if (isset($_SESSION['admin_logged_in'])) {
    header("Location: admin.php");
    exit();
}

$error = '';
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    include 'config.php';
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if ($password === $admin['password']) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            header("Location: admin.php");
            exit();
        } else {
            $error = "Invalid credentials.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureVault | Admin Portal</title>
    <link rel="shortcut icon" href="img/delsu.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <link rel="stylesheet" href="styles/admin_login.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            500: '#3b82f6',
                            600: '#2563eb'
                        },
                        secondary: {
                            500: '#10b981',
                            600: '#059669'
                        }
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 min-h-screen flex items-center">
    <div class="w-full max-w-md mx-auto p-6">
        <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="bg-gradient-to-r from-primary-500 to-primary-600 p-6 text-center">
                <p class="text-primary-100 mt-1">Administrator Access Only</p>
            </div>
            
            <div class="p-6">
                <?php if ($error): ?>
                <div class="bg-red-50 text-red-600 px-4 py-3 rounded-lg mb-4 flex items-start">
                    <i data-feather="alert-circle" class="w-5 h-5 mr-2 mt-0.5"></i>
                    <span><?= $error ?></span>
                </div>
                <?php endif; ?>
                      <img src="img/delsulogo-preview.png" class="delsu-logo"  alt="">

                <form method="POST" autocomplete="off" class="space-y-5">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Username</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i data-feather="user" class="text-gray-400"></i>
                            </div>
                            <input type="text" name="username" required 
                                class="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full" 
                                placeholder="Enter admin username">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i data-feather="lock" class="text-gray-400"></i>
                            </div>
                            <input type="password" name="password" required 
                                class="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-full" 
                                placeholder="Enter your password">
                        </div>
                    </div>
                    
                    <button type="submit" 
                        class="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-primary-500 hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 transition-colors duration-200">
                        <i data-feather="log-in" class="w-4 h-4 mr-2"></i>
                        Authenticate
                    </button>
                </form>
            </div>
            
            <div class="bg-gray-50 px-6 py-4 text-center border-t border-gray-200">
                <p class="text-xs text-gray-500">
                    <i data-feather="alert-triangle" class="w-3 h-3 inline mr-1"></i>
                    Unauthorized access is strictly prohibited
                </p>
            </div>
        </div>
    </div>
    
    <script>
        feather.replace();
    </script>
</body>
</html>