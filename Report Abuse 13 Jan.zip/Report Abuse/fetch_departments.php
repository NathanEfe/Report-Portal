<?php
require_once 'cbase.php';

if(isset($_POST['faculty_id'])) {
    $config = new Config();
    $pdo = $config->connect();
    $faculty_id = intval($_POST['faculty_id']);

    $stmt = $pdo->prepare("SELECT id, name AS DepartmentName 
                           FROM departments 
                           WHERE faculty_id = ?");
    $stmt->execute([$faculty_id]);

    echo '<option value="" disabled selected>Select a department</option>';
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<option value="'.$row['id'].'">'.$row['DepartmentName'].'</option>';
    }
}
?>
