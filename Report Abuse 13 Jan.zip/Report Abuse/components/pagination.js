// Pagination Web Component
class CustomPagination extends HTMLElement {
  connectedCallback() {
    this.render();
  }

  render() {
    const params = new URLSearchParams(window.location.search);
    const currentPage = parseInt(params.get('page')) || 1;
    const totalPages = this.getTotalPages();
    const search = params.get('search') || '';
    const status = params.get('status') || '';
    const abuseType = params.get('abuse_type') || '';

    if (totalPages <= 1) {
      this.innerHTML = '';
      return;
    }

    let html = '<nav class="flex justify-center items-center space-x-2" aria-label="Pagination">';

    // Previous button
    if (currentPage > 1) {
      html += `<a href="admin.php?page=${currentPage - 1}${this.buildQueryParams(search, status, abuseType)}" class="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition">
        Previous
      </a>`;
    } else {
      html += '<button disabled class="px-3 py-2 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed">Previous</button>';
    }

    // Page numbers
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    if (startPage > 1) {
      html += `<a href="admin.php?page=1${this.buildQueryParams(search, status, abuseType)}" class="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition">1</a>`;
      if (startPage > 2) {
        html += '<span class="px-3 py-2">...</span>';
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      if (i === currentPage) {
        html += `<button class="px-3 py-2 rounded-lg bg-blue-600 text-white font-semibold">${i}</button>`;
      } else {
        html += `<a href="admin.php?page=${i}${this.buildQueryParams(search, status, abuseType)}" class="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition">${i}</a>`;
      }
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        html += '<span class="px-3 py-2">...</span>';
      }
      html += `<a href="admin.php?page=${totalPages}${this.buildQueryParams(search, status, abuseType)}" class="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition">${totalPages}</a>`;
    }

    // Next button
    if (currentPage < totalPages) {
      html += `<a href="admin.php?page=${currentPage + 1}${this.buildQueryParams(search, status, abuseType)}" class="px-3 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition">
        Next
      </a>`;
    } else {
      html += '<button disabled class="px-3 py-2 rounded-lg border border-gray-300 text-gray-400 cursor-not-allowed">Next</button>';
    }

    html += '</nav>';
    this.innerHTML = html;
  }

  getTotalPages() {
    // This will be calculated server-side; we need to get it from the page
    const paginationData = document.querySelector('[data-total-pages]');
    if (paginationData) {
      return parseInt(paginationData.getAttribute('data-total-pages')) || 1;
    }
    return 1;
  }

  buildQueryParams(search, status, abuseType) {
    let params = '';
    if (search) params += `&search=${encodeURIComponent(search)}`;
    if (status) params += `&status=${encodeURIComponent(status)}`;
    if (abuseType) params += `&abuse_type=${encodeURIComponent(abuseType)}`;
    return params;
  }
}

customElements.define('custom-pagination', CustomPagination);
