<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

// Database connection
    include 'config.php';


// Get POST data
$report_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$status = isset($_POST['status']) ? trim($_POST['status']) : '';

// Validate inputs
if ($report_id <= 0 || empty($status)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid report ID or status']);
    exit();
}

// Validate status value
$valid_statuses = ['New', 'in-progress', 'resolved'];
if (!in_array($status, $valid_statuses)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid status value']);
    exit();
}

// Update the report status
$sql = "UPDATE abuse_reports SET status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['success' => false, 'error' => 'Database prepare failed: ' . $conn->error]);
    exit();
}

$stmt->bind_param('si', $status, $report_id);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Status updated successfully']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database update failed: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
