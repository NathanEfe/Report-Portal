<?php

$conn = new mysqli("localhost", "root", "", "report");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>