class AdminHeader extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          width: 100%;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header-container {
          background-color: #ffffff;
          padding: 0 1.5rem;
          height: 74px;
          padding-top:15px;
        }
        .header-content {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 64px;
          max-width: 100%;
        }
        .logo {
          font-weight: 700;
          font-size: 1.25rem;
          color: rgba(37,99,235,1);
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }
        .nav-links {
          display: flex;
          gap: 1.5rem;
        }
        .nav-link {
          color: #4b5563;
          font-weight: 500;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          transition: color 0.2s;
        }
        .nav-link:hover {
          color: #4f46e5;
        }
        .user-menu {
          display: flex;
          align-items: center;
          gap: 1rem;
        }
        .avatar {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background-color: #e5e7eb;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          object-fit: contain;
        }
        .mobile-menu-btn {
          display: none;
        }
        .bg-logout{
        background-color: #f87171;
        color: white;
        border:none;
        padding:0.5rem 1rem;
        border-radius:0.375rem;
        }

        .flex{
        display: flex;}
        @media (max-width: 768px) {
          .nav-links {
            display: none;
          }
          .mobile-menu-btn {
            display: block;
          }
        }
      </style>
      <div class="header-container">
        <div class="header-content">
                  <a href="admin.php"> 
          <div class="bg-primary-500 px-6 py-4">
                <div class="flex items-center">
                    <img src="img/delsulogo.jpg" class="delsu-logo"  alt="">
                </div>
            </div>
            </a>

        
          
          <div class="user-menu">
            <div class="avatar">
              <img src="./img/admin.jpg">
            </div>
            <a href="./admin_logout.php">
            <button class="bg-logout">
              <i data-feather="menu"></i>
              <span class="">Logout</span>
            </button>
            </a>
          </div>
        </div>
      </div>
    `;
  }

}

customElements.define('admin-header', AdminHeader);


