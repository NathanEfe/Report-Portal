<?php
    class Config{
        private $host = 'localhost';
        private $user = 'root';
        private $password = '';
        private $dbname = 'report';

        public function connect(){
            $dsn = 'mysql:host='.$this->host.';dbname='.$this->dbname;
            $pdo = new PDO($dsn, $this->user, $this->password);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
            $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            return $pdo;
        }
public function FetchAllFacultiesDropdown() {
    
   $q = "SELECT * FROM faculties WHERE deleted = '0' ORDER BY name ASC ";
            $query = $this->connect()->prepare($q);
            $query->execute();
            $faculties = $query->fetchAll();
            foreach($faculties as $faculty){
                echo '
                    <option value="'.$faculty->id.'">'.$faculty->name. '</option>
                '; 
            }
    }
public function FetchAllUnitsDropdown() {
    
   $q = "SELECT * FROM units WHERE deleted = '0' ORDER BY name ASC ";
            $query = $this->connect()->prepare($q);
            $query->execute();
            $units = $query->fetchAll();
            foreach($units as $unit){
                echo '
                    <option value="'.$unit->id.'">'.$unit->name.'</option>
                '; 
            }
    }

    }
?>