<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thank You - Report Received</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="shortcut icon" href="img/delsu.png">
      <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script src="https://unpkg.com/feather-icons"></script>
     <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            500: '#3b82f6',
                            600: '#2563eb',
                        },
                        secondary: {
                            500: '#64748b',
                            600: '#475569',
                        }
                    }
                }
            }
        }
    </script>

  <style>
    body {
      background-color: #f2f7fa;
      font-family: 'Segoe UI', sans-serif;
    }

    .thank-you-container {
      max-width: 600px;
      margin: 80px auto;
      background: white;
      padding: 2rem 2.5rem;
      border-radius: 15px;
      text-align: center;
      box-shadow: 0 4px 25px rgba(0,0,0,0.08);
    }

    h1 {
      color: #3b82f6;
      font-weight: 600;
    }

    .message {
      font-size: 1.1rem;
      color: #333;
      margin-top: 1rem;
    }

    .support-box {
      margin-top: 2rem;
      background-color: #f8f9fc;
      padding: 1rem;
      border-radius: 10px;
    }

    .support-box h5 {
      font-size: 1rem;
      color: #444;
    }

    .support-box p {
      margin: 0.3rem 0;
      font-size: 0.95rem;
    }

    .home-link {
      margin-top: 2rem;
    }
  </style>
</head>
  <body class="bg-gray-50 min-h-screen">
    <div class="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="bg-primary-500 px-6 py-4">
                <div class="flex items-center">
                    <i data-feather="shield" class="text-white mr-3"></i>
                    <h1 class="text-2xl font-bold text-white text-center">Thank You</h1>
                </div>
            </div>
 
  <div class="thank-you-container">
    <h1>Thank You</h1>
    <p class="message">Your anonymous report has been successfully submitted.</p>
    

    <div class="support-box">
      <h5>Need Further Help?</h5>
      <p><strong>Counseling:</strong> +234 800 123 4567</p>
      <p><strong>Legal Aid:</strong> +234 701 234 5678</p>
      <p><strong>NGO Support:</strong> support@yourngo.org</p>
    </div>

    <div class="home-link">
      <a href="index.php" class="btn btn-outline-primary">Submit Another Report</a>
    </div>
  </div>
         </div>
    </div>

</body>
</html>
