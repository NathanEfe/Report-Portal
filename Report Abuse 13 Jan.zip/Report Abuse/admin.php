<?php
    include 'config.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit();
}

// Pagination settings
$records_per_page = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max($page, 1); // Ensure page is at least 1

// Get search and filter parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? trim($_GET['status']) : '';
$abuse_type_filter = isset($_GET['abuse_type']) ? trim($_GET['abuse_type']) : '';

// Build WHERE clause
$where_clauses = [];
if (!empty($search)) {
    $search_term = '%' . $conn->real_escape_string($search) . '%';
    $where_clauses[] = "(name LIKE '$search_term' OR description LIKE '$search_term' OR perpetrator_name LIKE '$search_term' OR location_of_incident LIKE '$search_term')";
}
if (!empty($status_filter)) {
    $status_val = $conn->real_escape_string($status_filter);
    $where_clauses[] = "status = '$status_val'";
}
if (!empty($abuse_type_filter)) {
    $abuse_val = $conn->real_escape_string($abuse_type_filter);
    $where_clauses[] = "abuse_type = '$abuse_val'";
}

$where_sql = empty($where_clauses) ? '' : 'WHERE ' . implode(' AND ', $where_clauses);

// Get total number of records with filters
$count_sql = "SELECT COUNT(*) as total FROM abuse_reports $where_sql";
$count_result = $conn->query($count_sql);
$count_row = $count_result->fetch_assoc();
$total_records = $count_row['total'];
$total_pages = ceil($total_records / $records_per_page);

// Ensure page doesn't exceed total pages
if ($page > $total_pages && $total_pages > 0) {
    $page = $total_pages;
}

// Calculate offset
$offset = ($page - 1) * $records_per_page;

// Get paginated results with filters
$sql = "SELECT * FROM abuse_reports $where_sql ORDER BY created_at DESC LIMIT $offset, $records_per_page";
$result = $conn->query($sql);
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Report Radar - Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
  <script src="https://unpkg.com/feather-icons"></script>
  <link rel="shortcut icon" href="img/delsu.png">
  <link rel="stylesheet" href="styles/style.css">
  <script src="components/report-card.js"></script>
  <script src="components/pagination.js"></script>
  <script src="components/admin-header.js"></script>
</head>
<body class="bg-gray-50">
  <admin-header></admin-header>

  <div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-8 abuse-flex">
      <h1 class="text-3xl font-bold text-gray-800">Abuse Reports</h1>
      <div class="flex items-center space-x-4">
        <form method="GET" class="flex items-center space-x-2">
          <div class="relative">
            <input type="text" name="search" placeholder="Search reports..." value="<?= htmlspecialchars($search) ?>" class="pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
            <i data-feather="search" class="absolute left-3 top-2.5 text-gray-400"></i>
          </div>
          <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">Search</button>
        </form>
        <button onclick="toggleFilters()" class="flex items-center space-x-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition filter-btn">
          <i data-feather="filter"></i>
          <span>Filters</span>
        </button>
      </div>
    </div>

    <!-- Filters Panel -->
    <div id="filters-panel" class="hidden bg-white p-6 rounded-lg shadow-md mb-8">
      <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
          <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
            <option value="">All Status</option>
            <option value="New" <?= $status_filter === 'New' ? 'selected' : '' ?>>New</option>
            <option value="in-progress" <?= $status_filter === 'in-progress' ? 'selected' : '' ?>>In-Progress</option>
            <option value="resolved" <?= $status_filter === 'resolved' ? 'selected' : '' ?>>Resolved</option>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 mb-2">Abuse Type</label>
          <select name="abuse_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
            <option value="">All Types</option>
            <option value="Physical Abuse" <?= $abuse_type_filter === 'Physical Abuse' ? 'selected' : '' ?>>Physical Abuse</option>
            <option value="Verbal/Emotional Abuse" <?= $abuse_type_filter === 'Verbal/Emotional Abuse' ? 'selected' : '' ?>>Verbal/Emotional Abuse</option>
            <option value="Sexual Assault" <?= $abuse_type_filter === 'Sexual Assault' ? 'selected' : '' ?>>Sexual Assault</option>
            <option value="Stalking" <?= $abuse_type_filter === 'Stalking' ? 'selected' : '' ?>>Stalking</option>
          </select>
        </div>
        <div class="flex items-end space-x-2">
          <button type="submit" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">Apply Filters</button>
          <a href="admin.php" class="flex-1 bg-gray-400 hover:bg-gray-500 text-white px-4 py-2 rounded-lg transition text-center">Reset</a>
        </div>
      </form>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="reports-container">
      <!-- Reports as cards -->
      <?php
      if ($result && $result->num_rows > 0):
        while($row = $result->fetch_assoc()):
          $abuse_type = htmlspecialchars($row['abuse_type']);
          $location = htmlspecialchars($row['location_of_incident']);
          $perpetrator_name = !empty($row['perpetrator_name']) ? htmlspecialchars($row['perpetrator_name']) : 'Anonymous';
          $relationship = htmlspecialchars($row['relationship_to_perpetrator']);
          $incident_date = htmlspecialchars($row['incident_datetime']);
          $status = isset($row['status']) ? htmlspecialchars($row['status']) : 'New';
          $report_id = (int)$row['id'];
          
          // Determine status badge color
          $status_color = 'bg-blue-100 text-blue-800';
          $status_label = 'New';
          if ($status === 'in-progress') {
            $status_color = 'bg-yellow-100 text-yellow-800';
            $status_label = 'In-Progress';
          } elseif ($status === 'resolved') {
            $status_color = 'bg-green-100 text-green-800';
            $status_label = 'Resolved';
          }
      ?>  
      <div class="report-card bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden transition-transform duration-300 hover:scale-105">
        <div class="p-6">
          <!-- Status Badge -->
          <div class="flex justify-between items-start mb-4">
            <h3 class="text-lg font-semibold text-gray-800"><?= $abuse_type ?></h3>
            <span class="px-3 py-1 rounded-full text-xs font-medium <?= $status_color ?>">
              <?= $status_label ?>
            </span>
          </div>
          <hr>

          
          <!-- Report Summary -->
          <div class="space-y-3 text-sm text-gray-600 mt-4">
            <div class="flex items-center">
              <i data-feather="user" class="w-4 h-4 mr-2 text-gray-400"></i>
              <span><?= $perpetrator_name ?></span>
            </div>
            <div class="flex items-center">
              <i data-feather="briefcase" class="w-4 h-4 mr-2 text-gray-400"></i>
              <span><?= $relationship ?></span>
            </div>
            <div class="flex items-center">
              <i data-feather="map-pin" class="w-4 h-4 mr-2 text-gray-400"></i>
              <span><?= $location ?></span>
            </div>
            <div class="flex items-center">
              <i data-feather="calendar" class="w-4 h-4 mr-2 text-gray-400"></i>
              <span><?= $incident_date ?></span>
            </div>
          </div>
          
          <!-- View Details Button -->
          <button onclick="viewReportDetails(<?= $report_id ?>)" class="mt-6 w-25 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition">
            View Details
          </button>
        </div>
      </div>
      <?php endwhile; else: ?>
      <div class="col-span-full text-center py-10 text-gray-500">
        <p>No reports submitted yet.</p>
      </div>
      <?php endif; ?>
    </div>
    <br>
    <custom-pagination class="mt-10" data-total-pages="<?= $total_pages ?>"></custom-pagination>
  </div>

  <!-- Report Detail Modal -->
  <div id="reportModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
      <div class="flex justify-between items-center border-b p-6 sticky top-0 bg-white z-10">
        <h3 class="text-xl font-bold text-gray-800">Report Details</h3>
        <button onclick="closeModal()" class="text-gray-500 hover:text-gray-700">
          <i data-feather="x"></i>
        </button>
      </div>
      <div class="p-6" id="modal-content">
        <!-- Content will be loaded here -->
      </div>
    </div>
  </div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script src="script.js"></script>
  <script>
    feather.replace();

    function viewReportDetails(reportId) {
      // Fetch report details via AJAX
      fetch('get_report_details.php?id=' + reportId)
        .then(response => response.json())
        .then(report => {
          displayReportModal(report);
        })
        .catch(error => {
          console.error('Error fetching report:', error);
          Swal.fire('Error loading report details');
        });
    }

    function displayReportModal(report) {
      const modal = document.getElementById('reportModal');
      const content = document.getElementById('modal-content');
      
      // Format the detailed view with all report information
      content.innerHTML = `
        <div class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 class="font-semibold text-gray-600">Reporter Name</h4>
              <p class="mt-1 text-gray-800">${report.name || 'Anonymous'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Abuse Type</h4>
              <p class="mt-1 text-gray-800">${report.abuse_type}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Perpetrator Name</h4>
              <p class="mt-1 text-gray-800">${report.perpetrator_name || 'Not provided'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Position</h4>
              <p class="mt-1 text-gray-800">${report.relationship_to_perpetrator}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Faculty</h4>
              <p class="mt-1 text-gray-800">${report.faculty || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Department</h4>
              <p class="mt-1 text-gray-800">${report.department || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Unit</h4>
              <p class="mt-1 text-gray-800">${report.unit || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Incident Date/Time</h4>
              <p class="mt-1 text-gray-800">${report.incident_datetime}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Location</h4>
              <p class="mt-1 text-gray-800">${report.location_of_incident}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Physical Injuries</h4>
              <p class="mt-1 text-gray-800">${report.physical_injuries}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Medical Attention Sought</h4>
              <p class="mt-1 text-gray-800">${report.medical_attention}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Reported to Authorities</h4>
              <p class="mt-1 text-gray-800">${report.reported_to_authorities}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Witnesses Present</h4>
              <p class="mt-1 text-gray-800">${report.witnesses_present}</p>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Update Status</h4>
            <div class="flex items-end space-x-2">
              <div class="flex-1">
                <select id="status-select" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                  <option value="New" ${report.status === 'New' ? 'selected' : ''}>New</option>
                  <option value="in-progress" ${report.status === 'in-progress' ? 'selected' : ''}>In-Progress</option>
                  <option value="resolved" ${report.status === 'resolved' ? 'selected' : ''}>Resolved</option>
                </select>
              </div>
              <button onclick="updateReportStatus(${report.id})" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                Save Status
              </button>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Description of Incident</h4>
            <div class="bg-gray-50 p-4 rounded-lg">
              <p class="text-gray-700 whitespace-pre-wrap">${report.description}</p>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Additional Information</h4>
            <div class="bg-gray-50 p-4 rounded-lg">
              <p class="text-gray-700 whitespace-pre-wrap">${report.additional_info || 'None'}</p>
            </div>
          </div>
          
          ${report.evidence_file ? `
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Evidence</h4>
            <a href="${report.evidence_file}" target="_blank" class="text-blue-600 hover:text-blue-800 underline">View Evidence File</a>
          </div>
          ` : ''}
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Submitted</h4>
            <p class="text-gray-700">${report.created_at}</p>
          </div>
        </div>
      `;
      
      modal.classList.remove('hidden');
      feather.replace();
    }

    function closeModal() {
      document.getElementById('reportModal').classList.add('hidden');
    }
  </script>
  <script>
    // Toggle filters panel
    function toggleFilters() {
      const panel = document.getElementById('filters-panel');
      panel.classList.toggle('hidden');
    }

    function viewReportDetails(reportId) {
      // Fetch report details via AJAX
      fetch('get_report_details.php?id=' + reportId)
        .then(response => response.json())
        .then(report => {
          displayReportModal(report);
        })
        .catch(error => {
          console.error('Error fetching report:', error);
          Swal.fire('Error loading report details');
        });
    }

    function updateReportStatus(reportId) {
      const status = document.getElementById('status-select').value;
      
      fetch('update_report_status.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'id=' + reportId + '&status=' + encodeURIComponent(status)
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Reload the page when the user clicks okay
          Swal.fire({
            title: "Status Updated Successfully!",
            icon: "success",
            draggable: true
          }).then(() => {
            location.reload();
          });
        } else {
          Swal.fire('Error updating status: ' + (data.error || 'Unknown error'));
        }
      })
      .catch(error => {
        console.error('Error updating status:', error);
        Swal.fire('Error updating status');
      });
    }

    function displayReportModal(report) {
      const modal = document.getElementById('reportModal');
      const content = document.getElementById('modal-content');
      
      // Format the detailed view with all report information
      content.innerHTML = `
        <div class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="">
              <h4 class="font-semibold text-gray-600">Reporter Name</h4>
              <p class="mt-1 text-gray-800">${report.name || 'Anonymous'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Abuse Type</h4>
              <p class="mt-1 text-gray-800">${report.abuse_type}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Perpetrator Name</h4>
              <p class="mt-1 text-gray-800">${report.perpetrator_name || 'Not provided'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Position</h4>
              <p class="mt-1 text-gray-800">${report.relationship_to_perpetrator}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Faculty</h4>
              <p class="mt-1 text-gray-800">${report.faculty || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Department</h4>
              <p class="mt-1 text-gray-800">${report.department || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Unit</h4>
              <p class="mt-1 text-gray-800">${report.unit || 'N/A'}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Incident Date/Time</h4>
              <p class="mt-1 text-gray-800">${report.incident_datetime}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Location</h4>
              <p class="mt-1 text-gray-800">${report.location_of_incident}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Physical Injuries</h4>
              <p class="mt-1 text-gray-800">${report.physical_injuries}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Medical Attention Sought</h4>
              <p class="mt-1 text-gray-800">${report.medical_attention}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Reported to Authorities</h4>
              <p class="mt-1 text-gray-800">${report.reported_to_authorities}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Witnesses Present</h4>
              <p class="mt-1 text-gray-800">${report.witnesses_present}</p>
            </div>
            <div>
              <h4 class="font-semibold text-gray-600">Witness Contact Info</h4>
              <p class="mt-1 text-gray-800">${report.witness_contact || 'Not provided'}</p>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Update Status</h4>
            <div class="flex items-end space-x-2">
              <div class="flex-1">
                <select id="status-select" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                  <option value="New" ${report.status === 'New' ? 'selected' : ''}>New</option>
                  <option value="in-progress" ${report.status === 'in-progress' ? 'selected' : ''}>In-Progress</option>
                  <option value="resolved" ${report.status === 'resolved' ? 'selected' : ''}>Resolved</option>
                </select>
              </div>
              <button onclick="updateReportStatus(${report.id})" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg transition">
                Save Status
              </button>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Description of Incident</h4>
            <div class="bg-gray-50 p-4 rounded-lg">
              <p class="text-gray-700 whitespace-pre-wrap">${report.description}</p>
            </div>
          </div>
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Additional Information</h4>
            <div class="bg-gray-50 p-4 rounded-lg">
              <p class="text-gray-700 whitespace-pre-wrap">${report.additional_info || 'None'}</p>
            </div>
          </div>
          
          ${report.evidence_file ?`
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Evidence</h4>
            <a href="${report.evidence_file}" target="_blank" class="text-blue-600 hover:text-blue-800 underline">View Evidence File</a>
          </div>
          ` : ''}
          
          <div class="border-t pt-6">
            <h4 class="font-semibold text-gray-600 mb-3">Submitted</h4>
            <p class="text-gray-700">${report.created_at}</p>
          </div>
        </div>
      `;
      
      modal.classList.remove('hidden');
      feather.replace();
    }
  </script>
</body>
</html>