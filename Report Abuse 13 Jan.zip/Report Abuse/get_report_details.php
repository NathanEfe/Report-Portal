<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

// Database connection
    include 'config.php';
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// Get report ID from query string
$report_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($report_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid report ID']);
    exit();
}

// Fetch report details
$sql = "SELECT * FROM abuse_reports WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $report_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $report = $result->fetch_assoc();
    // Return as JSON with proper encoding
    header('Content-Type: application/json');
    echo json_encode($report);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Report not found']);
}

$stmt->close();
$conn->close();
?>
